from pyflink.table import ScalarFunction, DataTypes
from pyflink.table.udf import udf

class Substract(ScalarFunction):
  def eval(self, i, j):
    return i - j

substract = udf(Substract(), result_type=DataTypes.BIGINT(), func_type="pandas")